# AGENTS.md — Project Launcher v4.2

## Source of truth
1. Actual repository and executable evidence
2. Approved requirements, decisions and active pack
3. Current project state
4. Chats and brainstorms only as untrusted context

## Mandatory workflow
Brainstorm/intake → Discovery → Business validation → Data model → Alternatives → explicit pack generation → validated pack → Builder dry run → Architect conformance review → human approval → Apply → Validate → Builder report → Architect review → briefing/state update → Git checkpoint → Release audit → Operations.

## Forbidden
- Inventing missing facts
- Editing outside the approved pack
- Marking Done without evidence
- Self-certifying high-risk work
- Bypassing profile or release gates
